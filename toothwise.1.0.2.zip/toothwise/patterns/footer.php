<?php
/**
 * Title: Footer
 * Slug: toothwise/footer
 * Categories: toothwise, footer
 */
?>

<!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","right":"20px","bottom":"40px","left":"20px"}},"color":{"background":"#1c1c1c"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="background-color:#1c1c1c;padding-top:60px;padding-right:20px;padding-bottom:40px;padding-left:20px"><!-- wp:group {"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|Background"}}},"spacing":{"margin":{"top":"0px","bottom":"0px"}}},"textColor":"Background","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide has-background-color has-text-color has-link-color" style="margin-top:0px;margin-bottom:0px"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:site-logo /-->

<!-- wp:site-title {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"},":hover":{"color":{"text":"var:preset|color|primary"}}}},"typography":{"lineHeight":"1"}},"textColor":"white"} /--></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Sed mattis at est in cursus. Suspendisse lacinia dui ut nibh sagittis condimentum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|50","margin":{"top":"35px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-top:35px"><!-- wp:image {"id":941,"width":"16px","sizeSlug":"full","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"16px"}}} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/fooadd.png'); ?>" alt="" class="wp-image-941" style="width:16px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('31 Hoylake Rd, Cheshire, England.','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|50","margin":{"top":"15px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-top:15px"><!-- wp:image {"id":941,"width":"16px","sizeSlug":"full","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"16px"}}} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/foophn.png'); ?>" alt="" class="wp-image-941" style="width:16px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><a href="tel:07908 712026"><?php esc_html_e('07908 712026','toothwise'); ?></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|50","margin":{"top":"15px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-top:15px"><!-- wp:image {"id":941,"width":"16px","sizeSlug":"full","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"16px"}}} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/foomail.png'); ?>" alt="" class="wp-image-941" style="width:16px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><a href="mailto:demo@example.com"><?php esc_html_e('demo@example.com','toothwise'); ?></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:social-links {"iconBackgroundColor":"primary","iconBackgroundColorValue":"#c19977","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"},"margin":{"top":"var:preset|spacing|60"}}}} -->
<ul class="wp-block-social-links has-icon-background-color" style="margin-top:var(--wp--preset--spacing--60)"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"twitter"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /-->

<!-- wp:social-link {"url":"#","service":"youtube"} /-->

<!-- wp:social-link {"url":"#","service":"pinterest"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"shape","style":{"spacing":{"padding":{"top":"8px","bottom":"8px","left":"32px","right":"32px"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group shape has-primary-background-color has-background" style="padding-top:8px;padding-right:32px;padding-bottom:8px;padding-left:32px"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"letterSpacing":"1px","textTransform":"capitalize","fontStyle":"normal","fontWeight":"500"}},"textColor":"white","fontSize":"regular"} -->
<h5 class="wp-block-heading has-white-color has-text-color has-link-color has-regular-font-size" style="font-style:normal;font-weight:500;letter-spacing:1px;text-transform:capitalize"><?php esc_html_e('Popular Service','toothwise'); ?></h5>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Home','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Teeth Whitening','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Cosmetic Dentistry','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Implant Dentistry','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Microscopic Dentistry','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Painless Dentistry','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('General Dentistry','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Dental Care Services','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Emergency Services','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Our Practice','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"shape","style":{"spacing":{"padding":{"top":"8px","bottom":"8px","left":"32px","right":"32px"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group shape has-primary-background-color has-background" style="padding-top:8px;padding-right:32px;padding-bottom:8px;padding-left:32px"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"letterSpacing":"1px","textTransform":"capitalize","fontStyle":"normal","fontWeight":"500"}},"textColor":"white","fontSize":"regular"} -->
<h5 class="wp-block-heading has-white-color has-text-color has-link-color has-regular-font-size" style="font-style:normal;font-weight:500;letter-spacing:1px;text-transform:capitalize"><?php esc_html_e('Clinic Gallery','toothwise'); ?></h5>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:gallery {"columns":3,"linkTo":"none","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"}}}} -->
<figure class="wp-block-gallery has-nested-images columns-3 is-cropped"><!-- wp:image {"id":267,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-267" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":264,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-264" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":263,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-263" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":261,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-261" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":258,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-258" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":246,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-246" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":245,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-245" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":243,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-243" style="border-width:2px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":301,"sizeSlug":"large","linkDestination":"none","style":{"border":{"width":"2px"}},"borderColor":"white"} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/gal.jpg'); ?>" alt="" class="has-border-color has-white-border-color wp-image-301" style="border-width:2px"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","style":{"color":{"background":"#1c1c1c"},"elements":{"link":{"color":{"text":"var:preset|color|white"},":hover":{"color":{"text":"var:preset|color|primary"}}}},"spacing":{"padding":{"top":"20px","bottom":"20px","left":"20px","right":"20px"}},"border":{"top":{"color":"#ffffff1a","width":"1px"},"right":[],"bottom":[],"left":[]}},"textColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide has-white-color has-text-color has-background has-link-color" style="border-top-color:#ffffff1a;border-top-width:1px;background-color:#1c1c1c;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"textColor":"Background"} -->
<p class="has-background-color has-text-color"><?php esc_html_e('© Copyright 2024. All Rights Reserved.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|Background"}}}},"textColor":"Background"} -->
<p class="has-background-color has-text-color has-link-color"><a rel="noreferrer noopener" href="<?php echo esc_url('https://www.flythemes.net/'); ?>" target="_blank"><?php esc_html_e('Fly Themes','toothwise'); ?></a> <?php esc_html_e('and','toothwise'); ?> <a href="<?php echo esc_url( __('https://wordpress.org','toothwise')); ?>"><?php esc_html_e('WordPress','toothwise'); ?></a>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->