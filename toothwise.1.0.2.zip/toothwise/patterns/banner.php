<?php
/**
 * Title: Banner
 * Slug: toothwise/banner
 * Categories: toothwise, banner
 */
?>

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() . '/images/slider.jpg'); ?>","id":595,"dimRatio":0,"overlayColor":"secondary","isUserOverlayColor":true,"minHeight":700,"contentPosition":"center center","isDark":false,"align":"full","style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"0px","bottom":"0px"}}}} -->
<div class="wp-block-cover alignfull is-light" style="margin-top:0px;margin-bottom:0px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px;min-height:700px"><span aria-hidden="true" class="wp-block-cover__background has-secondary-background-color has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-595" alt="" src="<?php echo esc_url( get_template_directory_uri() . '/images/slider.jpg'); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"constrained","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"70%"} -->
<div class="wp-block-column" style="flex-basis:70%"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"shape","style":{"spacing":{"padding":{"top":"10px","bottom":"10px","left":"24px","right":"24px"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group shape has-primary-background-color has-background" style="padding-top:10px;padding-right:24px;padding-bottom:10px;padding-left:24px"><!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"500","textTransform":"uppercase","letterSpacing":"2px"}},"textColor":"white","fontSize":"body-text","fontFamily":"rubik"} -->
<h4 class="wp-block-heading has-white-color has-text-color has-link-color has-rubik-font-family has-body-text-font-size" style="font-style:normal;font-weight:500;letter-spacing:2px;text-transform:uppercase"><?php esc_html_e('Toothwise dental care','toothwise'); ?></h4>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"600","lineHeight":"1","textTransform":"capitalize","letterSpacing":"2px"},"spacing":{"margin":{"top":"20px"}}},"textColor":"secondary","fontSize":"banner-title"} -->
<h2 class="wp-block-heading has-secondary-color has-text-color has-banner-title-font-size" style="margin-top:20px;font-style:normal;font-weight:600;letter-spacing:2px;line-height:1;text-transform:capitalize"><?php esc_html_e('The art of','toothwise'); ?><br><?php esc_html_e('perfecting smile','toothwise'); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"#091d3e"}}},"typography":{"lineHeight":"1.8"},"color":{"text":"#091d3e"},"spacing":{"margin":{"top":"30px"}}},"fontSize":"medium"} -->
<p class="has-text-color has-link-color has-medium-font-size" id="line1" style="color:#091d3e;margin-top:30px;line-height:1.8"><?php esc_html_e('Sed sollicitudin magna et luctus elementum. Donec id lectus tortor.','toothwise'); ?><br> <?php esc_html_e('Maecenas mollis mauris eu sodales ultrices.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"50px"}}},"layout":{"type":"flex"}} -->
<div class="wp-block-buttons" style="margin-top:50px"><!-- wp:button {"style":{"border":{"radius":"5px"},"spacing":{"padding":{"left":"28px","right":"28px","top":"18px","bottom":"18px"}},"typography":{"textTransform":"uppercase","letterSpacing":"2px","fontStyle":"normal","fontWeight":"500"}},"fontFamily":"cinzel"} -->
<div class="wp-block-button has-cinzel-font-family" style="font-style:normal;font-weight:500;letter-spacing:2px;text-transform:uppercase"><a class="wp-block-button__link wp-element-button" style="border-radius:5px;padding-top:18px;padding-right:28px;padding-bottom:18px;padding-left:28px"><?php esc_html_e('Make Appointment','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->