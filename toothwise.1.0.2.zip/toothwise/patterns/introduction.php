<?php
/**
 * Title: Introduction
 * Slug: toothwise/intro
 * Categories: toothwise, intro
 */
?>

<!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"60px","bottom":"60px","left":"20px","right":"20px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:60px;padding-right:20px;padding-bottom:60px;padding-left:20px"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:columns {"isStackedOnMobile":false,"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns is-not-stacked-on-mobile"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() . '/images/about.jpg'); ?>","id":1841,"dimRatio":0,"isUserOverlayColor":true,"minHeight":100,"minHeightUnit":"%","isDark":false,"style":{"border":{"radius":"30px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover is-light" style="border-radius:30px;min-height:100%"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-1841" alt="" src="<?php echo esc_url( get_template_directory_uri() . '/images/about.jpg'); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":1832,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"30px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/about2.jpg'); ?>" alt="" class="wp-image-1832" style="border-radius:30px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":1836,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"30px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/about3.jpg'); ?>" alt="" class="wp-image-1836" style="border-radius:30px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"className":"section_head","layout":{"type":"constrained"}} -->
<div class="wp-block-group section_head"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"shape","style":{"spacing":{"padding":{"top":"10px","bottom":"10px","left":"24px","right":"24px"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group shape has-primary-background-color has-background" style="padding-top:10px;padding-right:24px;padding-bottom:10px;padding-left:24px"><!-- wp:heading {"textAlign":"left","level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"uppercase"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"body-text","fontFamily":"rubik"} -->
<h4 class="wp-block-heading has-text-align-left has-white-color has-text-color has-link-color has-rubik-font-family has-body-text-font-size" style="font-style:normal;font-weight:400;text-transform:uppercase"><?php esc_html_e('About Our Clinic','toothwise'); ?></h4>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:heading {"textAlign":"left","style":{"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"fontSize":"section-title"} -->
<h2 class="wp-block-heading has-text-align-left has-section-title-font-size" style="margin-top:var(--wp--preset--spacing--20)"><?php esc_html_e('Your Great Smile Begins With ToothWise','toothwise'); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left"} -->
<p class="has-text-align-left"><?php esc_html_e('Pellentesque tempor non urna in eleifend. Integer vitae fringilla elit. Nunc nec vehicula enim, sit amet posuere dui. Vivamus viverra facilisis euismod.','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns {"isStackedOnMobile":false} -->
<div class="wp-block-columns is-not-stacked-on-mobile"><!-- wp:column {"verticalAlignment":"center","width":"80px"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:80px"><!-- wp:group {"className":"vertical-center pos-relative","style":{"dimensions":{"minHeight":"80px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}},"border":{"radius":"50%"}},"backgroundColor":"primary","layout":{"type":"default"}} -->
<div class="wp-block-group vertical-center pos-relative has-primary-background-color has-background" style="border-radius:50%;min-height:80px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":41,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/tooth.png'); ?>" alt="" class="wp-image-41"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('Complete Dental Care','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"5px"}}}} -->
<p style="margin-top:5px"><?php esc_html_e('Nam quam enim, ultricies id convallis blandit, varius nec dui. Integer vel sem egestas, aliquam ante eget, vulputate neque.','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"2px","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div style="margin-top:var(--wp--preset--spacing--40);height:2px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"isStackedOnMobile":false} -->
<div class="wp-block-columns is-not-stacked-on-mobile"><!-- wp:column {"verticalAlignment":"center","width":"80px"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:80px"><!-- wp:group {"className":"pos-relative vertical-center","style":{"dimensions":{"minHeight":"80px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}},"border":{"radius":"50%"}},"backgroundColor":"primary","layout":{"type":"default"}} -->
<div class="wp-block-group pos-relative vertical-center has-primary-background-color has-background" style="border-radius:50%;min-height:80px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":59,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/scalpel.png'); ?>" alt="" class="wp-image-59"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('Painless Treatment','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"5px"}}}} -->
<p style="margin-top:5px"><?php esc_html_e('Nam quam enim, ultricies id convallis blandit, varius nec dui. Integer vel sem egestas, aliquam ante eget, vulputate neque.','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"2px","style":{"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
<div style="margin-top:var(--wp--preset--spacing--30);height:2px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"border":{"radius":"0px"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" style="border-radius:0px"><?php esc_html_e('More About Us','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->