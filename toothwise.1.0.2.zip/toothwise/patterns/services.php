<?php
/**
 * Title: Services
 * Slug: toothwise/service
 * Categories: toothwise, service
 */
?>

<!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","bottom":"60px","left":"20px","right":"20px"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"section-bg","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-section-bg-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:60px;padding-right:20px;padding-bottom:60px;padding-left:20px"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"className":"section_head","layout":{"type":"constrained"}} -->
<div class="wp-block-group section_head"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"shape","style":{"spacing":{"padding":{"top":"10px","bottom":"10px","left":"24px","right":"24px"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group shape has-primary-background-color has-background" style="padding-top:10px;padding-right:24px;padding-bottom:10px;padding-left:24px"><!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"uppercase"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"body-text","fontFamily":"rubik"} -->
<h4 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color has-rubik-font-family has-body-text-font-size" style="font-style:normal;font-weight:400;text-transform:uppercase"><?php esc_html_e('We Provide','toothwise'); ?></h4>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"fontSize":"section-title"} -->
<h2 class="wp-block-heading has-text-align-center has-section-title-font-size" style="margin-top:var(--wp--preset--spacing--20)"><?php esc_html_e('Best Dental Service for you','toothwise'); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><?php esc_html_e('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque id mollis justo. Sed ultricies purus velit, id vehicula nisl pellentesque non. Sed nec tellus quam.','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"},"margin":{"top":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"service-box","style":{"border":{"radius":"12px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group service-box has-white-background-color has-background" style="border-radius:12px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"54px","bottom":"34px","right":"30px","left":"47px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:54px;padding-right:30px;padding-bottom:34px;padding-left:47px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":71,"width":"70px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/ser1.png'); ?>" alt="" class="wp-image-71" style="width:70px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"30px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:30px"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('General Dental Care','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"2"},"spacing":{"margin":{"top":"12px"}}}} -->
<p style="margin-top:12px;line-height:2"><?php esc_html_e('Lorem ipsum dolor sit amet, conse ctetur adipiscing elit. Duis at est id leo luctus gravida a in ipsum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"20px"}}}} -->
<div class="wp-block-buttons" style="margin-top:20px"><!-- wp:button {"textColor":"secondary","className":"is-style-outline","style":{"border":{"radius":"5px"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1"},"spacing":{"padding":{"left":"24px","right":"24px","top":"12px","bottom":"12px"}}},"borderColor":"primary"} -->
<div class="wp-block-button is-style-outline" style="font-style:normal;font-weight:500;line-height:1"><a class="wp-block-button__link has-secondary-color has-text-color has-link-color has-border-color has-primary-border-color wp-element-button" style="border-radius:5px;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px"><?php esc_html_e('Read More','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"service-box","style":{"border":{"radius":"12px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group service-box has-white-background-color has-background" style="border-radius:12px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"54px","bottom":"34px","right":"30px","left":"47px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:54px;padding-right:30px;padding-bottom:34px;padding-left:47px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":87,"width":"70px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/ser2.png'); ?>" alt="" class="wp-image-87" style="width:70px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"30px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:30px"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('Root Canal Therapy','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"2"},"spacing":{"margin":{"top":"12px"}}}} -->
<p style="margin-top:12px;line-height:2"><?php esc_html_e('Lorem ipsum dolor sit amet, conse ctetur adipiscing elit. Duis at est id leo luctus gravida a in ipsum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"20px"}}}} -->
<div class="wp-block-buttons" style="margin-top:20px"><!-- wp:button {"textColor":"secondary","className":"is-style-outline","style":{"border":{"radius":"5px"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1"},"spacing":{"padding":{"left":"24px","right":"24px","top":"12px","bottom":"12px"}}},"borderColor":"primary"} -->
<div class="wp-block-button is-style-outline" style="font-style:normal;font-weight:500;line-height:1"><a class="wp-block-button__link has-secondary-color has-text-color has-link-color has-border-color has-primary-border-color wp-element-button" style="border-radius:5px;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px"><?php esc_html_e('Read More','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"service-box","style":{"border":{"radius":"12px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group service-box has-white-background-color has-background" style="border-radius:12px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"54px","bottom":"34px","right":"30px","left":"47px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:54px;padding-right:30px;padding-bottom:34px;padding-left:47px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":88,"width":"70px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/ser3.png'); ?>" alt="" class="wp-image-88" style="width:70px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"30px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:30px"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('Cosmetic Dentistry','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"2"},"spacing":{"margin":{"top":"12px"}}}} -->
<p style="margin-top:12px;line-height:2"><?php esc_html_e('Lorem ipsum dolor sit amet, conse ctetur adipiscing elit. Duis at est id leo luctus gravida a in ipsum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"20px"}}}} -->
<div class="wp-block-buttons" style="margin-top:20px"><!-- wp:button {"textColor":"secondary","className":"is-style-outline","style":{"border":{"radius":"5px"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1"},"spacing":{"padding":{"left":"24px","right":"24px","top":"12px","bottom":"12px"}}},"borderColor":"primary"} -->
<div class="wp-block-button is-style-outline" style="font-style:normal;font-weight:500;line-height:1"><a class="wp-block-button__link has-secondary-color has-text-color has-link-color has-border-color has-primary-border-color wp-element-button" style="border-radius:5px;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px"><?php esc_html_e('Read More','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"26px","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div style="margin-top:0;margin-bottom:0;height:26px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"},"margin":{"top":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"service-box","style":{"border":{"radius":"12px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group service-box has-white-background-color has-background" style="border-radius:12px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"54px","bottom":"34px","right":"30px","left":"47px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:54px;padding-right:30px;padding-bottom:34px;padding-left:47px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":89,"width":"70px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/ser4.png'); ?>" alt="" class="wp-image-89" style="width:70px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"30px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:30px"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('Dental Implant','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"2"},"spacing":{"margin":{"top":"12px"}}}} -->
<p style="margin-top:12px;line-height:2"><?php esc_html_e('Lorem ipsum dolor sit amet, conse ctetur adipiscing elit. Duis at est id leo luctus gravida a in ipsum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"20px"}}}} -->
<div class="wp-block-buttons" style="margin-top:20px"><!-- wp:button {"textColor":"secondary","className":"is-style-outline","style":{"border":{"radius":"5px"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1"},"spacing":{"padding":{"left":"24px","right":"24px","top":"12px","bottom":"12px"}}},"borderColor":"primary"} -->
<div class="wp-block-button is-style-outline" style="font-style:normal;font-weight:500;line-height:1"><a class="wp-block-button__link has-secondary-color has-text-color has-link-color has-border-color has-primary-border-color wp-element-button" style="border-radius:5px;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px"><?php esc_html_e('Read More','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"service-box","style":{"border":{"radius":"12px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group service-box has-white-background-color has-background" style="border-radius:12px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"54px","bottom":"34px","right":"30px","left":"47px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:54px;padding-right:30px;padding-bottom:34px;padding-left:47px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":90,"width":"70px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/ser5.png'); ?>" alt="" class="wp-image-90" style="width:70px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"30px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:30px"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('Pediatric Dentistry','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"2"},"spacing":{"margin":{"top":"12px"}}}} -->
<p style="margin-top:12px;line-height:2"><?php esc_html_e('Lorem ipsum dolor sit amet, conse ctetur adipiscing elit. Duis at est id leo luctus gravida a in ipsum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"20px"}}}} -->
<div class="wp-block-buttons" style="margin-top:20px"><!-- wp:button {"textColor":"secondary","className":"is-style-outline","style":{"border":{"radius":"5px"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1"},"spacing":{"padding":{"left":"24px","right":"24px","top":"12px","bottom":"12px"}}},"borderColor":"primary"} -->
<div class="wp-block-button is-style-outline" style="font-style:normal;font-weight:500;line-height:1"><a class="wp-block-button__link has-secondary-color has-text-color has-link-color has-border-color has-primary-border-color wp-element-button" style="border-radius:5px;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px"><?php esc_html_e('Read More','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"service-box","style":{"border":{"radius":"12px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group service-box has-white-background-color has-background" style="border-radius:12px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"54px","bottom":"34px","right":"30px","left":"47px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:54px;padding-right:30px;padding-bottom:34px;padding-left:47px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":91,"width":"70px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/ser6.png'); ?>" alt="" class="wp-image-91" style="width:70px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"30px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:30px"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e('Teeth Whitening','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"2"},"spacing":{"margin":{"top":"12px"}}}} -->
<p style="margin-top:12px;line-height:2"><?php esc_html_e('Lorem ipsum dolor sit amet, conse ctetur adipiscing elit. Duis at est id leo luctus gravida a in ipsum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"20px"}}}} -->
<div class="wp-block-buttons" style="margin-top:20px"><!-- wp:button {"textColor":"secondary","className":"is-style-outline","style":{"border":{"radius":"5px"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1"},"spacing":{"padding":{"left":"24px","right":"24px","top":"12px","bottom":"12px"}}},"borderColor":"primary"} -->
<div class="wp-block-button is-style-outline" style="font-style:normal;font-weight:500;line-height:1"><a class="wp-block-button__link has-secondary-color has-text-color has-link-color has-border-color has-primary-border-color wp-element-button" style="border-radius:5px;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px"><?php esc_html_e('Read More','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|70"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--70)"><!-- wp:button {"textAlign":"center","backgroundColor":"secondary","style":{"border":{"radius":"0px"},"spacing":{"padding":{"left":"36px","right":"36px","top":"12px","bottom":"12px"}},"typography":{"letterSpacing":"2px","textTransform":"uppercase","fontStyle":"normal","fontWeight":"500"}}} -->
<div class="wp-block-button" style="font-style:normal;font-weight:500;letter-spacing:2px;text-transform:uppercase"><a class="wp-block-button__link has-secondary-background-color has-background has-text-align-center wp-element-button" style="border-radius:0px;padding-top:12px;padding-right:36px;padding-bottom:12px;padding-left:36px"><?php esc_html_e('View All Services','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->