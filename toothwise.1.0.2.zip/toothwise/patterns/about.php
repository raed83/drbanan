<?php
/**
 * Title: About
 * Slug: toothwise/about
 * Categories: toothwise, about
 */
?>

<!-- wp:group {"style":{"color":{"background":"#f8f8f8"},"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"60px","bottom":"60px","left":"20px","right":"20px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="background-color:#f8f8f8;margin-top:0;margin-bottom:0;padding-top:60px;padding-right:20px;padding-bottom:60px;padding-left:20px"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"id":43,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/about.png'); ?>" alt="" class="wp-image-43"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"className":"section_head","layout":{"type":"constrained"}} -->
<div class="wp-block-group section_head"><!-- wp:heading {"textAlign":"left","level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"600","textTransform":"uppercase","letterSpacing":"2px"},"elements":{"link":{"color":{"text":"var:preset|color|primary"}}}},"textColor":"primary","fontSize":"medium","fontFamily":"montserrat"} -->
<h4 class="wp-block-heading has-text-align-left has-primary-color has-text-color has-link-color has-montserrat-font-family has-medium-font-size" style="font-style:normal;font-weight:600;letter-spacing:2px;text-transform:uppercase"><?php esc_html_e('Gateways Travel','toothwise'); ?></h4>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"left","style":{"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"fontSize":"section-title"} -->
<h2 class="wp-block-heading has-text-align-left has-section-title-font-size" style="margin-top:var(--wp--preset--spacing--20)"><?php esc_html_e("Investigate All Corner's of the world with us",'toothwise'); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left"} -->
<p class="has-text-align-left"><?php esc_html_e('Aliquam sit amet mi lacus. Aliquam nulla nisi, maximus a pretium sit amet, elementum eu neque. Fusce interdum, erat at malesuada vestibulum, sapien arcu laoreet lacus, in auctor mi leo sed lectus. Phasellus elementum tellus vehicula risus sagittis, sed suscipit ante feugiat.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e('Pellentesque tempor non urna in eleifend. Integer vitae fringilla elit. Nunc nec vehicula enim, sit amet posuere dui. Vivamus viverra facilisis euismod. Nam tempor commodo bibendum.','toothwise'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"border":{"radius":"0px"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" style="border-radius:0px"><?php esc_html_e('Read More','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->