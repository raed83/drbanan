<?php
/**
 * Title: Header
 * Slug: toothwise/header
 * Categories: toothwise, header
 */
?>

<!-- wp:group {"style":{"color":{"background":"#091d3e"},"spacing":{"padding":{"right":"20px","left":"20px","top":"15px","bottom":"15px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="background-color:#091d3e;padding-top:15px;padding-right:20px;padding-bottom:15px;padding-left:20px"><!-- wp:group {"align":"full","style":{"spacing":{"padding":{"right":"20px","left":"20px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignfull" style="padding-right:20px;padding-left:20px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":329,"sizeSlug":"full","linkDestination":"none","className":"vertical-middle"} -->
<figure class="wp-block-image size-full vertical-middle"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/headadd.png'); ?>" alt="" class="wp-image-329"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('31 Hoylake Rd, Cheshire, England.','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":334,"sizeSlug":"full","linkDestination":"none","className":"vertical-middle"} -->
<figure class="wp-block-image size-full vertical-middle"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/headmail.png'); ?>" alt="" class="wp-image-334"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><a href="mailto:demo@example.com"><?php esc_html_e('demo@example.com','toothwise'); ?></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":336,"sizeSlug":"full","linkDestination":"none","className":"vertical-middle"} -->
<figure class="wp-block-image size-full vertical-middle"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/headtel.png'); ?>" alt="" class="wp-image-336"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><a href="tel:07908 712026"><?php esc_html_e('07908 712026','toothwise'); ?></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":338,"sizeSlug":"full","linkDestination":"none","className":"vertical-middle"} -->
<figure class="wp-block-image size-full vertical-middle"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/headclock.png'); ?>" alt="" class="wp-image-338"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e('Mon-Saturday, 9:00am - 5:00pm','toothwise'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->


<!-- wp:group {"style":{"spacing":{"padding":{"top":"15px","right":"20px","bottom":"15px","left":"20px"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="padding-top:15px;padding-right:20px;padding-bottom:15px;padding-left:20px"><!-- wp:group {"align":"full","style":{"spacing":{"padding":{"right":"20px","left":"20px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignfull" style="padding-right:20px;padding-left:20px"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"}} -->
<div class="wp-block-group"><!-- wp:site-logo /-->

<!-- wp:site-title {"style":{"typography":{"lineHeight":"1"}}} /--></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:navigation {"textColor":"secondary","style":{"typography":{"textTransform":"capitalize"}}} -->
<!-- wp:page-list /-->
<!-- /wp:navigation --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"border":{"radius":"4px"},"typography":{"letterSpacing":"1px","fontStyle":"normal","fontWeight":"500"},"spacing":{"padding":{"left":"24px","right":"24px","top":"16px","bottom":"16px"}}}} -->
<div class="wp-block-button" style="font-style:normal;font-weight:500;letter-spacing:1px"><a class="wp-block-button__link wp-element-button" style="border-radius:4px;padding-top:16px;padding-right:24px;padding-bottom:16px;padding-left:24px"><?php esc_html_e('Get Appointment','toothwise'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->