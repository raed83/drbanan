﻿=== Toothwise ===

Contributors: Flythemes
Requires at least: 6.7
Tested up to: 6.7
Requires PHP: 7.2
Stable tag: 1.0.2
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
Tags: education, e-commerce, blog, one-column, two-columns, three-columns, custom-colors, custom-menu, custom-logo, editor-style, featured-images, full-site-editing, block-patterns, rtl-language-support, sticky-post, threaded-comments, right-sidebar, custom-background, wide-blocks

== Description ==

Toothwise Dental is a comprehensive, full site editing WordPress theme tailored specifically for dental practices, dentists, and dental clinics, offering a seamless user experience with extensive customization options. This dentist-focused theme is designed with an intuitive layout, catering to the needs of dental professionals who want to establish a strong online presence. With its modern design and clean interface, Toothwise Dental provides an engaging platform to showcase dental services such as teeth whitening, orthodontics, cosmetic dentistry, and oral surgery. The theme features a range of pre-designed templates and block patterns, enabling users to effortlessly build pages for appointments, dental procedures, patient testimonials, and FAQs. Its responsive design ensures that your dental website looks flawless on any device, enhancing accessibility for patients seeking dental care on mobile or desktop. The built-in WooCommerce compatibility allows you to easily set up an online store for dental products like toothbrushes, mouthguards, and oral care essentials. Furthermore, Toothwise Dental integrates seamlessly with popular plugins, offering features like online booking forms, contact forms, and detailed service listings. This WordPress theme is SEO-optimized, helping dentists rank higher on search engines, and its fast-loading pages contribute to a better user experience. The theme’s customization features include unlimited color schemes, typography options, and an array of block elements, making it easy for dental practitioners to align their website design with their brand identity. Built with the latest full site editing capabilities, Toothwise Dental empowers users to customize every aspect of their site without touching a single line of code, making it perfect for dentists looking to create a professional, trustworthy, and engaging website. With dedicated support and regular updates, Toothwise Dental is the ultimate choice for any dentist or dental clinic aiming to enhance their online visibility and attract more patients.
 
== Theme Resources == 

Theme is built using the following resource bundles:		
		
1) Details of images used in Screenshot:
        
	i) Image for theme screenshot, copyrights under Creative Commons CC0
		License: CC0 1.0 Universal (CC0 1.0)
	 	License URL: https://pxhere.com/en/license
		Source: https://pxhere.com/en/photo/1446755
	      Website: https://pxhere.com			

2) toothwise/assests
	* Fonts:
	  -  Jost
	     	Jost is designed by Owen Earl
		License:  These fonts are licensed under the Open Font License., Version 2.0.
		https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL#3b878279
		Source: https://fonts.google.com/specimen/Jost

	  -  Rubik
	     	Rubik is designed by Hubert and Fischer
		License:  These fonts are licensed under the Open Font License., Version 2.0.
		https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL#3b878279
		Source: https://fonts.google.com/specimen/Rubik
	

*   License

	 Toothwise WordPress Theme, Copyright 2025 Flythemes
	 Toothwise is distributed under the terms of the GNU GPL
        
For any help you can mail us at support[at]flythemes.net

== Toothwise log ==

= 1.0 =
*      Initial version release.

= 1.0.1 =
*      Fixed minor changes.

= 1.0.2 =
*      Removed redirection.